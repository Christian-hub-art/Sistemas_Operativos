#ifndef FUNCIONES_H
#define FUNCIONES_H

float imcFuntion(float masa, float altura);
void impMatriz(float mA, int N);
float matrixMult(int N, float mA, float mB);
void llenarMatriz (int N, float mA, float mB);
int printFuntion();

#endif
